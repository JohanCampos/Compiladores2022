int main()
{
    float a;
    a = 1.1;
    int i, inc, j;
    i = 0;
    inc = 2;
    read j;

    while (i < j)
    {
        i = i + inc;
        a = a*i;
    }

    if (a > 10.0)
    {
        print(a + i);
    }
}